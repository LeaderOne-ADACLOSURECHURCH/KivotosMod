# KivotosMod 修复记录

## 2026-10-14：高分辨率特效与联机显示

- 工作目录：`C:\Users\Sunbinbin\Documents\My Games\Terraria\tModLoader\ModSources\KivotosMod`。
- 路线：现有 tModLoader / .NET 8 模组源码修复，不修改游戏安装、存档或配置。
- 用户负责构建和游戏内验证；本次未构建、未启动游戏。
- 原文件备份：`C:\Users\Sunbinbin\AppData\Local\Temp\KivotosFix-d468a1229ef34ebc9a666f6fbbab8fa7`。

### 定位和修改

1. 像素化子弹的 `RenderPixelated` 混用了普通 `EnterShaderArea` / `EndShaderArea` 和离屏绘制，导致部分内容提前应用 `GameViewMatrix`，合成时再次应用缩放。`PixelatedRenderManager.IsRenderingToTarget` 现在使普通绘制辅助函数在该阶段使用单位矩阵，世界缩放仅在合成时应用。
2. 像素化和元球渲染目标原来只在加载时创建。`ResetRT2D` 原实现只改局部参数，没有更新调用者，也没有释放旧纹理。改为通过 `ref` 在绘制线程更新渲染目标，并在使用前按当前屏幕尺寸重建。像素化绘制也恢复原渲染目标和绘制标记。
3. `StudentWeaponClass.HoldItem` 在各端都能创建持枪射弹；`KivotosRangedWeaponProjectile.UpdateHeldProjectile` 却只更新本地所有者的位置，远端后坐力仍累积修改世界位置。这是武器贴图停留或漂移的明确代码路径。现在仅所有者创建，使用标准射弹数据同步瞄准方向，各端每次更新都重新锚定玩家位置，后坐力不再读取其他客户端的鼠标。日奈、惠的覆写沿用该逻辑。持枪射弹标记 `netImportant`，支持后来加入的玩家。
4. 平板换装只保存了本地选择。`TabletStudentAppearancePlayer` 现在实现 `SyncPlayer`、`CopyClientState`、`SendClientChanges`；`TabletNet` 增加消息 3（`AppearanceSync`），服务器按发送者身份应用并转发选择或取消状态。原有消息 1、2 和保存的学生编号不变。

### 确认范围

- 静态复查了上述调用路径、所有持枪位置覆写、包裹生成和普通武器代码。
- 参照本机 `D:\SteamLibrary\steamapps\common\tModLoader\tModLoader.xml` 中的 ModPlayer 同步和 `Projectile.netImportant` 说明。
- 检查了官方 [Item 源码补丁](https://github.com/tModLoader/tModLoader/blob/stable/patches/tModLoader/Terraria/Item.cs.patch) 和 [Player 辅助代码](https://github.com/tModLoader/tModLoader/blob/stable/patches/tModLoader/Terraria/Player.TML.cs)。模组内未找到自定义拾取拦截或自行删除地面武器的逻辑。
- `um kb search Terraria` 未返回结果，已中止；定位依据为现有模组源码和 tModLoader API。
- 用户确认包裹开出的武器和普通丢弃的武器均出现残留，尚未检查残留是否可再次拾取。因此，目前修正的是已定位的持枪贴图残留路径，真实地面物品的删除同步仍需实测区分。

### 用户构建后的检查项（尚未执行）

1. 双方均更新模组后，测试 1080p、1440p / 4K 和不同游戏缩放；游戏中切换分辨率，观察优香、乃爱等像素化子弹是否与普通粒子、枪口和命中点对齐。
2. P2 拾取普通丢弃武器及包裹开出的武器，手持后移动、慢慢转向、开火、切换物品；P1 观察原地是否仍有武器，以及持枪是否跟随 P2。交换 P1 / P2 角色复测。如果仍有残留，检查是否能拾取，以区分世界物品与贴图。
3. P1 / P2 分别切换优香、日奈、乃爱和取消换装，观察另一端；再让玩家后加入或重连，检查既有换装和持枪显示。
