﻿using KivotosMod.Content.Projs.Ranged.StudentWeapons.Millennium;
using KivotosMod.Globals.Classes;
using KivotosMod.Globals.Database.Enums;
using KivotosMod.Globals.Database.Lists;

namespace KivotosMod.Content.Items.Weapons.Ranged.StudentWeapons.Millennium
{
    public class YuzuWeapon : StudentWeaponClass
    {
        protected override void SetUpTextboxSettings(ref Color backgroundColor, ref Color backgroundEdgeColor, ref Color textColor, ref Color textEdgeColor)
        {
            textEdgeColor = Color.Lerp(Color.DarkRed, Color.DarkViolet, .35f);
            textColor = Color.White;
            backgroundColor = Color.Black * .32f;
            backgroundEdgeColor = Color.DarkRed;

        }

        protected override string Owner => "Yuzu";
        public override void SetStaticDefaults()
        {
            base.SetStaticDefaults();
            KivotosLists.ShinyRarityItemDictionary.Add(Type, KivotosRarityType.MutsukiBrown);
        }

        public override void SetDefaults()
        {
            base.SetDefaults();
            Item.useTime = Item.useAnimation = 57;
            Item.damage = 45;
            Item.knockBack = 1;
            Item.shootSpeed = 10f;
            Item.shoot = ProjectileType<YuzuWeaponHeldProj>();
        }
    }

}
