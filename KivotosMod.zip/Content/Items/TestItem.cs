using KivotosMod.Content.Items.Vanity.Nozomi;
using KivotosMod.Content.Projs.Ranged;
using KivotosMod.Content.Projs.Ranged.StudentWeapons.Millennium;
using KivotosMod.Cores.Halos;
using KivotosMod.Globals.Database.Paths;
using Terraria;
using Terraria.DataStructures;
using Terraria.ID;
using Terraria.ModLoader;

namespace KivotosMod.Content.Items
{
    public class TestItem : ModItem, ILocalizedModType
    {
        public override string LocalizationCategory => LocalizationsDatabase.ItemLocalization;
        public override void SetDefaults()
        {
            Item.damage = 50;
            Item.DamageType = DamageClass.Melee;
            Item.width = 40;
            Item.height = 40;
            Item.useTime = 20;
            Item.useAnimation = 20;
            Item.useStyle = ItemUseStyleID.Swing;
            Item.knockBack = 6;
            Item.value = Item.buyPrice(silver: 1);
            Item.rare = ItemRarityID.Blue;
            Item.UseSound = SoundID.Item1;
            Item.shoot = ProjectileType<GeneralAssaultRifleBullet>();
            Item.shootSpeed = 16;
            Item.autoReuse = true;
        }
        public override bool Shoot(Player player, EntitySource_ItemUse_WithAmmo source, Vector2 position, Vector2 velocity, int type, int damage, float knockback)
        {
            BaseHalo h = new NozomiHalo(player.whoAmI);
            player.AddHalo(h);
            return true;
        }

        public override void AddRecipes()
        {
            Recipe recipe = CreateRecipe();
            recipe.AddIngredient(ItemID.DirtBlock, 10);
            recipe.AddTile(TileID.WorkBenches);
            recipe.Register();
        }
    }
}
